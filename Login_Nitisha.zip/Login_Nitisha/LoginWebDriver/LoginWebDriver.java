package LoginWebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginWebDriver {
	public static void main(String[] args) throws InterruptedException {
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\NITISHAG\\Desktop\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("C:\\Users\\NITISHAG\\Desktop\\mod\\login.html");
	//user enters all valid data.
	try {
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);

		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(1000);
		driver.findElement(By.className("btn")).click();
		/*driver.findElement(By.name("userName")).clear();
		Thread.sleep(1000);

		driver.findElement(By.name("userPwd")).clear();
		Thread.sleep(1000);
		

		driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);

		driver.findElement(By.name("userPwd")).sendKeys("");
		Thread.sleep(1000);
	*/
	}
	catch (Exception e) {
		System.out.println("Some exception");
	}
	driver.findElement(By.name("userName")).clear();
	Thread.sleep(1000);

	driver.findElement(By.name("userPwd")).clear();
	Thread.sleep(1000);
	

	driver.findElement(By.name("userName")).sendKeys("capgemini");
	Thread.sleep(1000);

	driver.findElement(By.name("userPwd")).sendKeys("");
	Thread.sleep(1000);
	
	//user leaves password blank

		/*driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);

		driver.findElement(By.name("userPwd")).sendKeys("");
		Thread.sleep(1000);*/
	
		driver.findElement(By.className("btn")).click();
	
}
}
